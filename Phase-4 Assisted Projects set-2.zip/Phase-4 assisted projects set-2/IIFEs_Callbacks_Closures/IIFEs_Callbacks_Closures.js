//IIFE and Closure
const empId = (function() {
    let count = 0;
    return function() {
      ++count;
      return `emp${count}`;
    };
})();
  
console.log("New Emplyee IDs are listed here");
console.log("Will : "+empId()); 
console.log("Mike : "+empId()); 
console.log("Eleven : "+empId());
   

//Callbacks
console.log("\n");      //to start the output from the neext line
function fullName(firstName, lastName, callback){
    console.log("My name is " + firstName + " " + lastName);
    callback(lastName);
}
  
var greeting = function(ln){
    console.log('Welcome ' + ln);
};
  
fullName("Will", "Byers", greeting);
console.log("\n");
fullName("Mike", "Wheelers", greeting);
console.log("\n");
fullName("Eleven", "Hopper", greeting);
