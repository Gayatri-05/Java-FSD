import { Component,OnInit } from '@angular/core';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  class ="Class Binding";
  c=document.getElementsByClassName(this.class);
  setClass() {
    return "Class Binding using function";
}
f = document.getElementsByClassName(this.setClass());
  title = 'angular-class-style-bindings';

  status = "All good";
}
