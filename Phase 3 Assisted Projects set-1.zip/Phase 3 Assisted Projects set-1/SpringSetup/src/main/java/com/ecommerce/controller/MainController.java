package com.ecommerce.controller;


import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

import com.ecommerce.beans.CustomEventPublisher;

import org.springframework.context.ConfigurableApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

@Controller
public class MainController {
	
//	   @RequestMapping(value="customEvent",method=RequestMethod.GET)
//	   public String customEvent() {
//	      ConfigurableApplicationContext context = 
//	         new ClassPathXmlApplicationContext("main-servlet.xml");
//		  
//	      CustomEventPublisher cvp = 
//	         (CustomEventPublisher) context.getBean("customEventPublisher");
//	      
//	      cvp.publish();  
//	      cvp.publish();
//	      return "customEvent";
//	   }
	   
	   @RequestMapping(value="/customevent",method = RequestMethod.GET)
		public ModelAndView customEvent(ModelMap map) {
			
		   ConfigurableApplicationContext con = 
			         new ClassPathXmlApplicationContext("main-servlet.xml");
				  
			      CustomEventPublisher cvp = 
			         (CustomEventPublisher) con.getBean("customEventPublisher");
			cvp.publish();
			cvp.publish();
			ModelAndView mav=new ModelAndView();
			mav.setViewName("customEvent.jsp");
			return mav;
			
		}
           
}

