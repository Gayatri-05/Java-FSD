
public class DemoTryCatch 
{
    public static void main(String args[]) 
    {
        int i=10;
        try 
        {
            int j=i/0;
        }
        catch (ArithmeticException e) 
        {
            System.out.println("Operation cannot be done!"); 
        }
        finally 
        {
            System.out.println("Division of a number with zero is not possible");
        }
    }
}

