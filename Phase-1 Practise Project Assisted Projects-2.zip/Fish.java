
public class Fish
{  
    String name;  
    int age; 
    String color; 
    public Fish(String name, int age, String color) 
    { 
        this.name = name; 
        this.age = age; 
        this.color = color; 
    } 
    public String getName() 
    { 
        return name; 
    }  
    public int getAge() 
    { 
        return age; 
    } 
    public String getColor() 
    { 
        return color; 
    } 
    @Override
    public String toString() 
    { 
        return("Hi! My name is "+ this.getName()+ ".\nMy age and color are " + this.getAge()+ " and"+ this.getColor() + "."); 
    } 
    public static void main(String[] args) 
    { 
        Fish Nemo = new Fish("Bluewhale", 10 , " Blue gray"); 
        System.out.println(Nemo.toString()); 
    } 
}

