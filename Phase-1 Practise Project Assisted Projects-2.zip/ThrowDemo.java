
public class ThrowDemo
    {
        public static void main(String[] args)
        {

            int a=5,b=0,res;

            try
            {
                if(b==0)        
                    throw(new ArithmeticException("Division by zero is not possible."));
                else
                {
                    res = a / b;
                    System.out.print("\n\tThe result is : " + res);
                }
            }
            catch(ArithmeticException Ex)
            {
                System.out.print("\n\tError : " + Ex.getMessage());
            }

            System.out.print("\n\tEnd of program.");
        }
    }

