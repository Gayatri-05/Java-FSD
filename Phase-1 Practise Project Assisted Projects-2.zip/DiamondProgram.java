interface First 
{  
    default void display() 
    { 
        System.out.println("Default First"); 
    } 
} 
interface Second 
{  
    default void display() 
    { 
        System.out.println("Default Second"); 
    } 
}  
public class DiamondProgram implements First, Second 
{  
    public void display() 
    {  
        First.super.display(); 
        Second.super.display(); 
    } 
    public static void main(String args[]) 
    { 
    	DiamondProgram obj = new DiamondProgram(); 
        obj.display(); 
    } 
}


