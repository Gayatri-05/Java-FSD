
public class TestEncapsulation 
{     
    public static void main (String[] args)  
    { 
        Encapsulate obj = new Encapsulate(); 
        obj.setName("Anand"); 
        obj.setAge(20); 
        obj.setRoll(5); 
        System.out.println("Name: " + obj.getName()); 
        System.out.println("Age: " + obj.getAge()); 
        System.out.println("Roll no: " + obj.getRoll());      
    } 
}

