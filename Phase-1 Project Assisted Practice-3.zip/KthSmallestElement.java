
public class KthSmallestElement  
{    
	public void sortArr(int arr[])  
	{  
		int size = arr.length;  
		for(int i = 0; i < size; i++)  
		{  
			int temp = i;  
			for(int j = i + 1; j < size; j++)  
			{  
				if(arr[temp] > arr[j])  
				{  
					temp = j;  
				}   
			}    
			if(temp != i)  
			{  
				int t = arr[i];  
				arr[i] = arr[temp];  
				arr[temp] = t;   
			}  
		}  
	}  
	
	public int findKthSmallest(int arr[], int k)  
	{  
		sortArr(arr);  
		// kth smallest element lies at the k - 1 index  
		return arr[k - 1];  
	}   
	public static void main(String args[])  
	{   
		KthSmallestElement obj = new KthSmallestElement();  
		int arr[] = {1,56,7,23,78,45};  
		int size = arr.length;  
		int k = 4;  
		System.out.println("For the array: ");  
		for(int i = 0; i < size; i++)  
		{  
			System.out.print(arr[i] + " ");  
		}  
		int ele = obj.findKthSmallest(arr, k);  
		System.out.println();  
		System.out.println("The " + k + "th smallest element of the array is: " + ele);  
		System.out.println("\n");  
	}
}
