import java.util.*;

public class QueueExample 
{
	public static void main(String[] args) 
	{
		Queue<String> animalsQueue = new LinkedList<>();
		//elements of queue
		animalsQueue.add("Lion");
		animalsQueue.add("Tiger");
		animalsQueue.add("Rabbit");
		animalsQueue.add("Deer");
		animalsQueue.add("Giraffee");
		//prints queue
		System.out.println("Queue is : " + animalsQueue);
		System.out.println("Head of Queue : " + animalsQueue.peek());
		//removes head of queue
		animalsQueue.remove();
		System.out.println("After removing Head of Queue : " + animalsQueue);
		System.out.println("Size of Queue : " + animalsQueue.size());
	}
}
