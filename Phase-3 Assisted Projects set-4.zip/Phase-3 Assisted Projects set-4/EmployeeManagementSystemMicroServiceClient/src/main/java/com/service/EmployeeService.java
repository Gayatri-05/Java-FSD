package com.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.bean.Employee;
import com.dao.EmployeeDao;

@Service
public class EmployeeService {

	@Autowired
	EmployeeDao employeeDao;
	
	public List<Employee> getAllEmployee(){
		return employeeDao.findAll();
	}
	
	public String storeEmployee(Employee emp) {
		Optional<Employee> op=employeeDao.findById(emp.getId());
		if(op.isPresent()) {
			return "Employee id must be unique";
		}
		else {
			employeeDao.save(emp);
			return "Record stored successfully";
		}
	}
	
	public String updateEmployeeSalary(Employee emp) {
		Optional<Employee> op=employeeDao.findById(emp.getId());
		if(op.isPresent()) {
			Employee e=op.get();
			e.setSalary(emp.getSalary());
			employeeDao.saveAndFlush(e);		//updates existing record
			return "Record updated successfully";
		}
		else {
			return "Record not present";
		}
	}
	
	public String deleteEmployee(int id) {
		Optional<Employee> op=employeeDao.findById(id);
		if(op.isPresent()) {
			Employee e=op.get();
			employeeDao.delete(e);
			return "Record deleted successfully";
		}
		else {
			return "Record not present";
		}
	}
	
	public String findEmployee(int id) {
		Optional<Employee> op=employeeDao.findById(id);
		if(op.isPresent()) {
			Employee e=op.get();
			return e.toString();
		}
		else {
			return "Record not present";
		}
	}
	
//	public Employee findEmployeeById(int id) {
//		Optional<Employee> op=employeeDao.findById(id);
//		if(op.isPresent()) {
//			Employee e=op.get();
//			return e;
//		}
//		else {
//			return null;
//		}
//	}
}
