package com;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.autoconfigure.domain.EntityScan;
import org.springframework.cloud.netflix.eureka.EnableEurekaClient;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;

@SpringBootApplication
@EntityScan(basePackages = "com")
@EnableJpaRepositories(basePackages = "com.dao")
@EnableEurekaClient
public class EmployeeManagementSystemMicroServiceClientApplication {

	public static void main(String[] args) {
		SpringApplication.run(EmployeeManagementSystemMicroServiceClientApplication.class, args);
		System.out.println("Employee Management System micro service client server up..!");
	}

}
