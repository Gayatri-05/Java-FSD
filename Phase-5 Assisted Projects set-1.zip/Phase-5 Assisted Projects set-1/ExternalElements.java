package com;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class ExternalElements {

	public static void main(String[] args) {
		//To click on ‘OK’ button in pop up
		WebDriver driver = new ChromeDriver();
		driver.switchTo().alert().accept();
		
		//To click on ‘Cancel’ button in pop up   
		driver.switchTo().alert().dismiss();
		
		//To Capture the alert message
		driver.switchTo().alert().getText();
		
		//To enter the information
		driver.switchTo().alert().sendKeys("text");
		
		//To exit from the popup
		driver.close();
		
		//Opening new tab
		driver.findElement(By.id("xyz")).sendKeys(Keys.CONTROL + "t");
		
		//Opening new window
		driver.findElement(By.id("xyz")).sendKeys(Keys.CONTROL + "w");
	}

}
