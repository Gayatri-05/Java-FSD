package com;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class LocatorsCssAndXpath {

	public static void main(String[] args) {
		System.setProperty("webdriver.chrome.driver", "C:\\Users\\KOPPURAVURI\\Desktop\\Java EE\\Phase-5 workspace\\chromedriver.exe");
		WebDriver driver=new ChromeDriver();
		driver.manage().window().maximize();
		driver.manage().deleteAllCookies();
		driver.get("https://www.calculator.net/half-life-calculator.html")
;
		
		//Using CSS
		WebElement n = driver.findElement(By.cssSelector("input.login"));
		n.sendKeys("Java");
		String str = n.getAttribute("value");
		System.out.println("Attribute value: " + str);
		//driver.quit();
		
		//Using Xpath
		WebElement n1=driver.findElement(By.xpath(".//*[@id = 'content']/table[1]/tbody/tr/td/table/tbody/tr[2]/td[1]/input"));
        n1.sendKeys("100");
		//n1.sendKeys("Your-Name");// Will send values to First Name tab
	    String str1 = n1.getText();
	    System.out.println("Text is : " + str1);
	    driver.close();
	}
}
