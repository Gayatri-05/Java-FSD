package com;

import java.util.ArrayList;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.Select;

public class HadlingWebProperties {
	public static void main(String[] args) {
		
		System.setProperty("webdriver.chrome.driver", "C:\\Users\\KOPPURAVURI\\Desktop\\Java EE\\Phase-5 workspace\\chromedriver.exe");
		WebDriver driver=new ChromeDriver();
		driver.manage().window().maximize();
		//TextBox
		driver.findElement(By.id("username")).sendKeys("abcd@gmail.com"); 
		String userName= driver.findElement(By.id("username")).getText();  
		
		//Button
		driver.findElement(By.id("login")).click(); 
		
		//Radio Button
		driver.findElement(By.id("gender")).click(); 
		boolean state=driver.findElement(By.id("gender ")).isSelected();
		
		//Check box
		driver.findElement(By.id("vehicle ")).click(); 
		boolean status=driver.findElement(By.id("vehicle ")).isSelected();
		
		//Drop Down list
		Select fruits = new Select(driver.findElement(By.id("fruits")));
	    fruits.selectByVisibleText("Banana");
	    fruits.selectByIndex(1);
	    
	    //Link
	    driver.findElement(By.id("help")).click();
	    String linkText = driver.findElement(By.id("help")).getText();
	    
	    //Frame
	    driver.switchTo().frame("iframe1");
	    driver.switchTo().frame("id of the element");

		//Swiching between tabs in same browser
	    driver.findElement(By.linkText("Twitter Advertising Blog")).click();
	    ArrayList<String> tabs2 = new ArrayList<String> (driver.getWindowHandles());
	    driver.switchTo().window(tabs2.get(1));
		driver.switchTo().window(tabs2.get(0));
		
		//Web table/Html table
		//No.of Columns
        List <WebElement> col = driver.findElements(By.xpath(".//*[@id=\"leftcontainer\"]/table/thead/tr/th"));
        System.out.println("No of cols are : " +col.size()); 
        //No.of rows 
        List <WebElement> rows = driver.findElements(By.xpath(".//*[@id='leftcontainer']/table/tbody/tr/td[1]")); 
        System.out.println("No of rows are : " + rows.size());
        
        //Image
        driver.get("https://www.facebook.com/login/identify?ctx=recover");					
        //click on the "Facebook" logo on the upper left portion		
		driver.findElement(By.cssSelector("a[title=\"Go to Facebook home\"]")).click();							
		if (driver.getTitle().equals("Facebook - log in or sign up")) {							
			System.out.println("We are back at Facebook's homepage");					
		}
		else {			
            System.out.println("We are NOT in Facebook's homepage");	

		}
	}
}