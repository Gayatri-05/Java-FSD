package com;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class Locators {
	public static void main(String[] args) {
		System.setProperty("webdriver.chrome.driver", "C:\\Users\\KOPPURAVURI\\Desktop\\Java EE\\Phase-5 workspace\\chromedriver.exe");
		WebDriver driver=new ChromeDriver();
		driver.manage().window().maximize();
		driver.manage().deleteAllCookies();
		driver.get("https://login.yahoo.com/");
		driver.findElement(By.id("login-username")).sendKeys("rajanipriyakoppuravuri@yahoo.com"); //id locator for text box
		WebElement searchIcon = driver.findElement(By.id("login-signin"));//id locator for next button
		searchIcon.click();
		
		driver.findElement(By.linkText("Trouble Signing in?")).click();//linkText locator for links
		
		driver.findElement(By.cssSelector("#login-username")).sendKeys("rajanipriyakoppuravuri@yahoo.com");
		driver.findElement(By.cssSelector("#login-signin")).click();

		driver.get("https://www.google.com");
		driver.findElement(By.xpath("//input[@id='q']")).sendKeys("Selenium"); //xpath for search box
		WebElement searchButton = driver.findElement(By.xpath("//input[@id='Google Search']"));//xpath for search button

	}

}
