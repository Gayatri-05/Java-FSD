//using default Access Modifiers
class defAccessSpecifier
{ 
  void display() 
     { 
         System.out.println("Program for default access specifier"); 
     } 
} 

public class AccessModifiers {

	public static void main(String[] args) {
		//default
		System.out.println("Default Access Specifier");
		defAccessSpecifier obj = new defAccessSpecifier(); 		  
        obj.display(); 

	}
}


