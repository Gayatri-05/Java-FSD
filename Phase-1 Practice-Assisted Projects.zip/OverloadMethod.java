
class OverloadMethod {
	
public void area(int b,int h)
    {
         System.out.println("Area of Triangle : "+(0.5*b*h));
    }
    public void area(int s) 
    {
         System.out.println("Area of Square : "+(s*s));
    }

    public static void main(String args[])
   {

       OverloadMethod o=new OverloadMethod();
       o.area(15,20);
       o.area(5);  
   }
}