package sample1;
import sample.*;

public class PubAccess1 {

	public static void main(String[] args) {
		
		PubAccess obj = new PubAccess(); 
        obj.display();  
		
	}
}

