
package pack2;

	import pack1.*;

	public class ProtSpec1 extends ProtSpec {

		public static void main(String[] args) {
			ProtSpec1 obj = new ProtSpec1 ();   
		       obj.display();  
		}

	}