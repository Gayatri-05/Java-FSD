
//anonymous inner class
abstract class AnonymousInnerClass {
	   public abstract void display();
	}


	public class InnerClass3 {

	public static void main(String[] args) {
	AnonymousInnerClass obj = new AnonymousInnerClass() {

	         public void display() {
	            System.out.println("Anonymous Inner Class");
	         }
	      };
	      obj.display();
	   }
	}

