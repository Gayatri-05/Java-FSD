
public class InnerClass1 {

	 private String message="Welcome to Java"; 
	 
	 class Inner{  
	  void hello(){System.out.println(message+", Inner class program");}  
	 }  


	public static void main(String[] args) {

		InnerClass1 obj=new InnerClass1();
		InnerClass1.Inner in=obj.new Inner();  
		in.hello();  
	}
}

