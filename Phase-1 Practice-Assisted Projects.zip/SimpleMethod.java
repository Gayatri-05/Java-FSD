public class SimpleMethod {
	public int addnumbers(int a,int b) {
		int c=a+b;
		return c;
	}
public static void main(String[] args) {
	SimpleMethod x=new SimpleMethod();
	int result=x.addnumbers(5,10);
	System.out.println("Addition of numbers is "+result);
}
}


