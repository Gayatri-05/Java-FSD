//call by value method
public class CallMethod {

int s=10;

int numop(int s) {
	s =(s-10)/100;
	return(s);
}

public static void main(String args[]) {
	CallMethod res = new CallMethod();
	System.out.println("Before operation value of data is "+res.s);
	res.numop(100);
	System.out.println("After operation value of data is "+res.s);
	}
}

