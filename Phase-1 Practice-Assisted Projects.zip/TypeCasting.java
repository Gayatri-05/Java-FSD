
	public class TypeCasting {
		public static void main(String[] args) {
			System.out.println("Implicit type casting");
			byte a =10;
			short s = a;
			System.out.println(a);
			System.out.println("Conversion of byte to short : "+s);
			char ch = 'G';
			System.out.println(ch);
			int i = ch;
			System.out.println("Conversion of char to int : "+i);
			float f = ch;
			System.out.println("Conversion of char to float : "+f);
			double d = ch;
			System.out.println("Conversion of char to double : "+d);
			System.out.println("\nExplicit Type Casting" );
			
			double x = 65.7;
			System.out.println(x);
			int y = (int)x;
			System.out.println("Converion of double to int : "+y);
			
		}

	}

