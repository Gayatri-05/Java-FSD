import java.util.regex.*;

public class RegExp {

public static void main(String[] args) {

	String p = "[a-z]+";
	String c = "Assisted Project";
	Pattern pattern = Pattern.compile(p);
	Matcher check = pattern.matcher(c);
	
	while (check.find())
      	System.out.println( c.substring( check.start(), check.end() ) );
	}
}


