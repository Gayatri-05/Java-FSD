
public class assisArray {

public static void main(String[] args) {

//single-dimensional array
int x[]= {1,2,3,4,5};
for(int i=0;i<5;i++) {
System.out.println("Elements of array a: "+x[i]);
}


//multidimensional array
int[][] y = {
            {1,4,9}, 
            {16,25,36,49} };
      
      System.out.println("\nLength of row 1: " + y[0].length);
      }
}

