
class EmpInfo{
	int id;
	String name;
	//default constructor
	EmpInfo()
	{
		System.out.println("Employee Information");
	}
	//parameterized constructor
	EmpInfo(int i, String n)
	{
		id=i;
		name=n;
	}

void display() {
	System.out.println(id+" "+name);
	}
}

public class ConstDemo {

public static void main(String[] args) {

	EmpInfo emp1=new EmpInfo();
	EmpInfo emp2=new EmpInfo(2,"Raja");
	EmpInfo emp3=new EmpInfo(10,"Rajani");
	emp2.display();
	emp3.display();
	}
}

