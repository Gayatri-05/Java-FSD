package pack1;

	public class ProtSpec{

		protected void display() 
	    { 
	        System.out.println("This is protected access specifier"); 
	    } 
	}

